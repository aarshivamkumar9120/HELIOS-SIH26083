require("dotenv").config();

const express = require("express");
const path = require("path");
const mongoose = require("mongoose");

const app = express();
const PORT = process.env.PORT || 5000;

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

const wards = [
  {
    id: "W01",
    name: "Aliganj",
    city: "Lucknow",
    temperature: 43.2,
    humidity: 42,
    windSpeed: 2.4,
    ndvi: 0.18,
    ndbi: 0.62,
    populationDensity: 8800,
    elderlyPct: 11,
    outdoorWorkerPct: 24,
    lowIncomePct: 19,
    waterAccessPct: 74,
    shadePct: 31,
    latitude: 26.879,
    longitude: 80.946,
    risk: "EXTREME",
    riskScore: 91
  },
  {
    id: "W02",
    name: "Gomti Nagar",
    city: "Lucknow",
    temperature: 41.7,
    humidity: 46,
    windSpeed: 3.1,
    ndvi: 0.31,
    ndbi: 0.48,
    populationDensity: 7200,
    elderlyPct: 9,
    outdoorWorkerPct: 18,
    lowIncomePct: 13,
    waterAccessPct: 86,
    shadePct: 46,
    latitude: 26.856,
    longitude: 81.001,
    risk: "HIGH",
    riskScore: 76
  },
  {
    id: "W03",
    name: "Chowk",
    city: "Lucknow",
    temperature: 42.8,
    humidity: 51,
    windSpeed: 1.8,
    ndvi: 0.11,
    ndbi: 0.71,
    populationDensity: 11200,
    elderlyPct: 14,
    outdoorWorkerPct: 29,
    lowIncomePct: 27,
    waterAccessPct: 68,
    shadePct: 22,
    latitude: 26.865,
    longitude: 80.915,
    risk: "EXTREME",
    riskScore: 94
  },
  {
    id: "W04",
    name: "Hazratganj",
    city: "Lucknow",
    temperature: 40.9,
    humidity: 48,
    windSpeed: 2.7,
    ndvi: 0.22,
    ndbi: 0.57,
    populationDensity: 7600,
    elderlyPct: 10,
    outdoorWorkerPct: 20,
    lowIncomePct: 16,
    waterAccessPct: 82,
    shadePct: 39,
    latitude: 26.850,
    longitude: 80.950,
    risk: "MODERATE",
    riskScore: 61
  },
  {
    id: "W05",
    name: "Indira Nagar",
    city: "Lucknow",
    temperature: 41.9,
    humidity: 44,
    windSpeed: 2.2,
    ndvi: 0.16,
    ndbi: 0.64,
    populationDensity: 9100,
    elderlyPct: 12,
    outdoorWorkerPct: 23,
    lowIncomePct: 21,
    waterAccessPct: 76,
    shadePct: 28,
    latitude: 26.882,
    longitude: 80.994,
    risk: "HIGH",
    riskScore: 79
  }
];

function heatIndexC(tempC, humidity) {
  const T = tempC * 9 / 5 + 32;
  const R = humidity;

  // NOAA heat-index regression, with Celsius output.
  let HI = 0.5 * (T + 61.0 + ((T - 68.0) * 1.2) + (R * 0.094));

  if (HI >= 80) {
    HI =
      -42.379 +
      2.04901523 * T +
      10.14333127 * R -
      0.22475541 * T * R -
      0.00683783 * T * T -
      0.05481717 * R * R +
      0.00122874 * T * T * R +
      0.00085282 * T * R * R -
      0.00000199 * T * T * R * R;
  }

  return Number(((HI - 32) * 5 / 9).toFixed(1));
}

function classifyHeatIndex(hi) {
  if (hi < 27) return { level: "LOW", color: "#16a34a", advice: "Normal precautions." };
  if (hi < 32) return { level: "CAUTION", color: "#ca8a04", advice: "Stay hydrated and reduce prolonged heat exposure." };
  if (hi < 41) return { level: "HIGH", color: "#ea580c", advice: "Avoid strenuous outdoor activity; take frequent cooling breaks." };
  if (hi < 54) return { level: "VERY HIGH", color: "#dc2626", advice: "Heat illness is possible. Seek shade/cooling and monitor vulnerable people." };
  return { level: "EXTREME", color: "#7f1d1d", advice: "Dangerous heat. Avoid outdoor exposure and activate emergency heat measures." };
}

function calculateRisk(ward) {
  const ndviRisk = (1 - Math.min(Math.max(ward.ndvi, 0), 1)) * 20;
  const ndbiRisk = Math.min(Math.max(ward.ndbi, 0), 1) * 20;
  const vulnerability =
    (Math.min(ward.elderlyPct / 20, 1) * 15) +
    (Math.min(ward.outdoorWorkerPct / 40, 1) * 15) +
    (Math.min(ward.lowIncomePct / 40, 1) * 10);
  const heat = Math.min(Math.max((ward.temperature - 35) / 10, 0), 1) * 20;
  const shadeRisk = (1 - Math.min(ward.shadePct / 70, 1)) * 10;
  return Math.round(Math.min(100, heat + ndviRisk + ndbiRisk + vulnerability + shadeRisk));
}

app.get("/api/health", (req, res) => {
  res.json({
    success: true,
    service: "HELIOS API",
    status: "healthy",
    timestamp: new Date().toISOString()
  });
});

app.get("/api/wards", (req, res) => {
  const enriched = wards.map(w => ({
    ...w,
    heatIndex: heatIndexC(w.temperature, w.humidity),
    calculatedRisk: calculateRisk(w)
  }));
  res.json({ success: true, count: enriched.length, wards: enriched });
});

app.get("/api/wards/:id", (req, res) => {
  const ward = wards.find(w => w.id === req.params.id);
  if (!ward) return res.status(404).json({ success: false, message: "Ward not found" });

  const hi = heatIndexC(ward.temperature, ward.humidity);
  res.json({
    success: true,
    ward: {
      ...ward,
      heatIndex: hi,
      calculatedRisk: calculateRisk(ward),
      heatClassification: classifyHeatIndex(hi)
    }
  });
});

app.get("/api/alerts", (req, res) => {
  const alerts = wards
    .filter(w => w.risk === "EXTREME" || w.risk === "HIGH")
    .map(w => ({
      id: `AL-${w.id}`,
      wardId: w.id,
      ward: w.name,
      severity: w.risk,
      message: `${w.name}: extreme thermal stress conditions detected.`,
      temperature: w.temperature,
      humidity: w.humidity,
      heatIndex: heatIndexC(w.temperature, w.humidity),
      timestamp: new Date().toISOString()
    }));
  res.json({ success: true, count: alerts.length, alerts });
});

app.get("/api/dashboard", (req, res) => {
  const enriched = wards.map(w => ({
    ...w,
    heatIndex: heatIndexC(w.temperature, w.humidity),
    calculatedRisk: calculateRisk(w)
  }));

  const averageTemp = enriched.reduce((s, w) => s + w.temperature, 0) / enriched.length;
  const averageHI = enriched.reduce((s, w) => s + w.heatIndex, 0) / enriched.length;

  res.json({
    success: true,
    summary: {
      totalWards: wards.length,
      extremeWards: wards.filter(w => w.risk === "EXTREME").length,
      highWards: wards.filter(w => w.risk === "HIGH").length,
      averageTemperature: Number(averageTemp.toFixed(1)),
      averageHeatIndex: Number(averageHI.toFixed(1)),
      highestRiskWard: enriched.reduce((a, b) => a.calculatedRisk > b.calculatedRisk ? a : b).name
    },
    wards: enriched,
    generatedAt: new Date().toISOString()
  });
});

app.post("/api/heat-index", (req, res) => {
  const { temperature, humidity } = req.body;

  if (
    typeof temperature !== "number" ||
    typeof humidity !== "number" ||
    humidity < 0 || humidity > 100
  ) {
    return res.status(400).json({
      success: false,
      message: "temperature must be a number and humidity must be between 0 and 100."
    });
  }

  const heatIndex = heatIndexC(temperature, humidity);
  const classification = classifyHeatIndex(heatIndex);

  res.json({
    success: true,
    input: { temperature, humidity },
    heatIndex,
    unit: "°C",
    ...classification
  });
});

// Optional MongoDB connection: demo continues even if MongoDB is not configured.
if (process.env.MONGODB_URI) {
  mongoose.connect(process.env.MONGODB_URI)
    .then(() => console.log("MongoDB connected"))
    .catch(err => console.warn("MongoDB connection failed:", err.message));
}

app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(PORT, () => {
  console.log(`HELIOS running at http://localhost:${PORT}`);
});