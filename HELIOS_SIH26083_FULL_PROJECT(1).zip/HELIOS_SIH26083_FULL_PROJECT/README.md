# HELIOS — SIH26083 Full-Stack Prototype

Extreme Heatwave Early Warning and Human Thermal Stress Index.

## Stack
- Frontend: HTML5, CSS3, Vanilla JavaScript
- Backend: Node.js + Express REST API
- Database-ready: MongoDB + Mongoose (optional)
- GIS-ready: demo ward records expose temperature, humidity, NDVI, NDBI and vulnerability attributes
- Map: Leaflet via CDN

## Run
1. Install Node.js 18+.
2. Open terminal in this folder.
3. Run `npm install`.
4. Copy `.env.example` to `.env`.
5. MongoDB is optional for this demo.
6. Run `npm start`.
7. Open http://localhost:5000

## API
- GET `/api/health`
- GET `/api/dashboard`
- GET `/api/wards`
- GET `/api/wards/:id`
- GET `/api/alerts`
- POST `/api/heat-index` with `{ "temperature": 42, "humidity": 40 }`

## Notes
The demo uses seeded ward data in memory so it works immediately without MongoDB.
If `MONGODB_URI` is supplied, the server connects to MongoDB and can be extended to persist observations.

## Production upgrades
- Replace demo geometry with official ward GeoJSON/PostGIS.
- Connect IMD/weather station/satellite feeds.
- Add authentication and role-based access.
- Store historical observations and alert acknowledgements.
- Add ML forecasting/risk model.
- Add SMS/WhatsApp/email/push notification integrations.
- Add audit logs and monitoring.
