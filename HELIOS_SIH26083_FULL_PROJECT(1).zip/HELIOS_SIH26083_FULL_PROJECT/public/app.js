let map;
let markers = [];

function riskClass(risk) {
  return String(risk).toLowerCase();
}

function markerColor(risk) {
  if (risk === "EXTREME") return "#7f1d1d";
  if (risk === "HIGH") return "#dc2626";
  if (risk === "MODERATE") return "#ea580c";
  return "#16a34a";
}

function initMap() {
  map = L.map("map").setView([26.865, 80.95], 12);
  L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
    maxZoom: 19,
    attribution: "&copy; OpenStreetMap contributors"
  }).addTo(map);
}

async function getJSON(url, options) {
  const response = await fetch(url, options);
  const data = await response.json();
  if (!response.ok) throw new Error(data.message || "API error");
  return data;
}

function renderSummary(summary) {
  document.getElementById("summaryCards").innerHTML = `
    <div class="card"><div class="card-label">TOTAL WARDS</div><div class="card-value">${summary.totalWards}</div><div class="card-note">Monitored demo wards</div></div>
    <div class="card"><div class="card-label">EXTREME RISK</div><div class="card-value">${summary.extremeWards}</div><div class="card-note">Immediate attention</div></div>
    <div class="card"><div class="card-label">HIGH RISK</div><div class="card-value">${summary.highWards}</div><div class="card-note">Preventive action</div></div>
    <div class="card"><div class="card-label">AVG TEMPERATURE</div><div class="card-value">${summary.averageTemperature}°C</div><div class="card-note">Current demo observation</div></div>
    <div class="card"><div class="card-label">AVG HEAT INDEX</div><div class="card-value">${summary.averageHeatIndex}°C</div><div class="card-note">Human thermal stress</div></div>
  `;
}

function renderMap(wards) {
  markers.forEach(m => m.remove());
  markers = [];

  wards.forEach(w => {
    const marker = L.circleMarker([w.latitude, w.longitude], {
      radius: 11,
      color: markerColor(w.risk),
      fillColor: markerColor(w.risk),
      fillOpacity: .82,
      weight: 2
    }).addTo(map);

    marker.bindPopup(`
      <b>${w.name} (${w.id})</b><br>
      Temperature: ${w.temperature}°C<br>
      Humidity: ${w.humidity}%<br>
      Heat Index: ${w.heatIndex}°C<br>
      NDVI: ${w.ndvi}<br>
      NDBI: ${w.ndbi}<br>
      Risk Score: <b>${w.calculatedRisk}/100</b>
    `);

    markers.push(marker);
  });
}

function renderWardList(wards) {
  const sorted = [...wards].sort((a,b) => b.calculatedRisk - a.calculatedRisk);
  document.getElementById("wardList").innerHTML = sorted.map(w => `
    <div class="ward-item">
      <div class="ward-top">
        <span>${w.name}</span>
        <span>${w.calculatedRisk}/100</span>
      </div>
      <div class="progress">
        <div class="risk-${riskClass(w.risk)}" style="width:${w.calculatedRisk}%"></div>
      </div>
      <div class="card-note">${w.risk} • HI ${w.heatIndex}°C • NDVI ${w.ndvi} • NDBI ${w.ndbi}</div>
    </div>
  `).join("");
}

function renderAlerts(alerts) {
  document.getElementById("alertCount").textContent = `${alerts.length} active`;
  document.getElementById("alerts").innerHTML = alerts.length
    ? alerts.map(a => `
      <div class="alert">
        <strong>${a.severity} — ${a.ward}</strong>
        <div>${a.message}</div>
        <small>${a.temperature}°C • ${a.humidity}% RH • HI ${a.heatIndex}°C</small>
      </div>
    `).join("")
    : "<p>No active alerts.</p>";
}

function renderTable(wards) {
  document.getElementById("wardTable").innerHTML = wards.map(w => `
    <tr>
      <td><b>${w.name}</b><br><small>${w.id}</small></td>
      <td>${w.temperature}°C</td>
      <td>${w.humidity}%</td>
      <td>${w.ndvi}</td>
      <td>${w.ndbi}</td>
      <td>${w.elderlyPct}%</td>
      <td>${w.outdoorWorkerPct}%</td>
      <td>${w.shadePct}%</td>
      <td><span class="risk-pill pill-${riskClass(w.risk)}">${w.risk}</span></td>
    </tr>
  `).join("");
}

async function loadDashboard() {
  try {
    const [dashboard, alerts] = await Promise.all([
      getJSON("/api/dashboard"),
      getJSON("/api/alerts")
    ]);
    renderSummary(dashboard.summary);
    renderMap(dashboard.wards);
    renderWardList(dashboard.wards);
    renderAlerts(alerts.alerts);
    renderTable(dashboard.wards);
  } catch (error) {
    console.error(error);
    alert("Could not load dashboard. Check whether the Node.js server is running.");
  }
}

document.getElementById("heatForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  const temperature = Number(document.getElementById("temperature").value);
  const humidity = Number(document.getElementById("humidity").value);
  const box = document.getElementById("heatResult");

  box.innerHTML = "Calculating...";
  try {
    const data = await getJSON("/api/heat-index", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ temperature, humidity })
    });
    box.innerHTML = `
      <strong>${data.heatIndex}°C</strong>
      <div><b>${data.level}</b> — ${data.advice}</div>
    `;
  } catch (error) {
    box.textContent = error.message;
  }
});

document.getElementById("refreshBtn").addEventListener("click", loadDashboard);

initMap();
loadDashboard();